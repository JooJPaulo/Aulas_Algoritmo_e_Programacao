#include<stdio.h>

main() {
    int codigoCidade, estado, quantidadeVeiculos, quantidadeAcidentes, maiorIndiceAcidentes = 0, menorIndiceAcidentes = 0, somaAcidentes = 0, somaVeiculos = 0, quantidadeCidades = 0;
}