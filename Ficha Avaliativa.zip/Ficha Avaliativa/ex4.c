#include<stdio.h>

main() {
    float lado1, lado2, lado3, angulo;

    printf("Digite o primeiro lado do triangulo: ");
    scanf("%f", &lado1);

    printf("Digite o segundo lado do triangulo: ");
    scanf("%f", &lado2);

    printf("Digite o terceiro lado do triangulo: ");
    scanf("%f", &lado3);

    

    return 0;
}