#include<stdio.h>

main() {
    float x, y, origem, eixoX, eixoY, q1, q2, q3, q4;

    printf("Digite o valor de X: ");
    scanf("%f", &x);
    printf("Digite o valor de Y: ");
    scanf("%f", &y);

    origem = (x == 0 && y == 0);
    eixoX = (x != 0 && y == 0);
    eixoY = (x == 0 && y != 0);
    q1 = (x > 0 && y > 0);
    q2 = (x < 0 && y > 0);
    q3 = (x < 0 && y < 0);
    q4 = (x > 0 && y < 0);
    
    if (origem) {
        printf("O ponto está na origem.\n");
    }

    
    

    return 0;
}